import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-campaigns-annot-validate',
  templateUrl: './campaigns-annot-validate.component.html',
  styleUrls: ['./campaigns-annot-validate.component.css']
})
export class CampaignsAnnotValidateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
