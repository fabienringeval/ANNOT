export * from './delete-profile.actions';
export * from './delete-profile.selectors';
export * from './delete-profile.state';

export { DeleteProfileEffects } from './delete-profile.effects';
export { reducer } from './delete-profile.reducer';
export { featureName } from './delete-profile.state';
