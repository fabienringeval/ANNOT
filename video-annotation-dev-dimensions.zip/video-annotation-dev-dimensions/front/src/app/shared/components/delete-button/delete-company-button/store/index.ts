export * from './delete-company.actions';
export * from './delete-company.selectors';
export * from './delete-company.state';

export { DeleteCompanyEffects } from './delete-company.effects';
export { reducer } from './delete-company.reducer';
export { featureName } from './delete-company.state';
