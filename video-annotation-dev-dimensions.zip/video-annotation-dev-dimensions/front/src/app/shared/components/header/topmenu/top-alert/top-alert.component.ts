import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-top-alert',
  templateUrl: './top-alert.component.html',
  styleUrls: ['./top-alert.component.css']
})
export class TopAlertComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
