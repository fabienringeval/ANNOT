import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profil-homepage',
  templateUrl: './profil-homepage.component.html',
  styleUrls: ['./profil-homepage.component.css']
})
export class ProfilHomepageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
