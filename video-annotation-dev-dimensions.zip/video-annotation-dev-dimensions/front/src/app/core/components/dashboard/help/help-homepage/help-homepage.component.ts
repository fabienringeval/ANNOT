import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-help-homepage',
  templateUrl: './help-homepage.component.html',
  styleUrls: ['./help-homepage.component.css']
})
export class HelpHomepageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
