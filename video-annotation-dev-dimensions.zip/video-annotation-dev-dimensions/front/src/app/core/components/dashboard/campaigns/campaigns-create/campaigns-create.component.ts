import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-campaigns-create',
  templateUrl: './campaigns-create.component.html',
  styleUrls: ['./campaigns-create.component.css']
})
export class CampaignsCreateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
